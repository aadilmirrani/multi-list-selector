package com.reacttive.aadilmirrani.mlslibrary.listener

interface OnTagSelectListener {
    fun onTagSelect(index: Int)
}